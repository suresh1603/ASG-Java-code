package com.wipro.asg.viewbean;



public class PerformTransactionBean {
	private String payeeAccountNumber;
	private String payeeName;
	private String mobileNumber;
	private int amount;
	private int pbalance;
	private String remarks;
	private int transId;
	
	

	public PerformTransactionBean() {
	}

	public PerformTransactionBean(String payeeAccountNumber, String payeeName, String mobileNumber, int amount,
			String remarks, int transId, int pbalance) {
		super();
		this.payeeAccountNumber = payeeAccountNumber;
		this.payeeName = payeeName;
		this.mobileNumber = mobileNumber;
		this.amount = amount;
		this.remarks = remarks;
		this.transId = transId;
		this.pbalance = pbalance;
		
		
	}

	public String getPayeeAccountNumber() {
		return payeeAccountNumber;
	}

	public void setPayeeAccountNumber(String payeeAccountNumber) {
		this.payeeAccountNumber = payeeAccountNumber;
	}

	public String getPayeeName() {
		return payeeName;
	}

	public void setPayeeName(String payeeName) {
		this.payeeName = payeeName;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public int getAmount() {
		return amount;
	}

	public void setAmount(int amount) {
		this.amount = amount;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public int getTransId() {
		return transId;
	}

	public void setTransId(int transId) {
		this.transId = transId;
	}
	public int getPbalance() {
		return pbalance;
	}

	public void setPbalance(int pbalance) {
		this.pbalance = pbalance;
	}
}
