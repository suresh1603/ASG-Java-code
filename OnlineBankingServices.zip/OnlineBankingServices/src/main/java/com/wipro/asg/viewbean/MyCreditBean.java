package com.wipro.asg.viewbean;

public class MyCreditBean {
	private int fromAccount;
	private String senderName;
	private int cramount;
	private String remarks;
	
	
	public MyCreditBean() {
		
	}
	
	public MyCreditBean(int fromAccount, String senderName, int cramount, String remarks) {
		super();
		this.fromAccount = fromAccount;
		this.senderName = senderName;
		this.cramount = cramount;
		this.remarks = remarks;
		
	}
	
	public int getFromAccount() {
		return fromAccount;
	}
	public void setFromAccount(int fromAccount) {
		this.fromAccount = fromAccount;
	}
	public String getSenderName() {
		return senderName;
	}
	public void setSenderName(String senderName) {
		this.senderName = senderName;
	}
	public int getCramount() {
		return cramount;
	}
	public void setCramount(int cramount) {
		this.cramount = cramount;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	
}
