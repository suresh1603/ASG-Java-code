package com.wipro.asg.viewbean;



public class MyDebitBean {
	private String toAccount;
	private String payName;
	private int damount;
	private String remarks;
	private int amount;
	private int checkbalance;
	
	
	public String getToAccount() {
		return toAccount;
	}
	public MyDebitBean(String toAccount, String payName, int damount, String remarks, int amount, int checkbalance) {
		super();
		this.toAccount = toAccount;
		this.payName = payName;
		this.damount = damount;
		this.remarks = remarks;
		this.amount = amount;
		this.checkbalance = checkbalance;
	}	
	
	public void setToAccount(String toAccount) {
		this.toAccount = toAccount;
	}
	public String getPayName() {
		return payName;
	}
	public void setPayName(String payName) {
		this.payName = payName;
	}
	public int getDamount() {
		return damount;
	}
	public void setDamount(int damount) {
		this.damount = damount;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	public MyDebitBean() {
		
	}
	public int getAmount() {
		return amount;
	}
	public void setAmount(int amount) {
		this.amount = amount;
	}
	public int getCheckbalance() {
		return checkbalance;
	}
	public void setCheckbalance(int checkbalance) {
		this.checkbalance = checkbalance;
	}
	
}
