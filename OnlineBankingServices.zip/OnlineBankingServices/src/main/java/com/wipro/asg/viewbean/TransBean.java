package com.wipro.asg.viewbean;

public class TransBean {
	private int transId;
	
	public TransBean() {
	
		
	}
	public TransBean(int transId) {
		super();
		this.transId = transId;
	}

	public int getTransId() {
		return transId;
	}

	public void setTransId(int transId) {
		this.transId = transId;
	}

}
