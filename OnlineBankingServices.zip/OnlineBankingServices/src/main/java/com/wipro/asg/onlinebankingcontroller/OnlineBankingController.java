package com.wipro.asg.onlinebankingcontroller;



import java.util.HashMap;
import java.util.Iterator;

import java.util.Map;

import java.util.Random;


import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;



import org.springframework.boot.autoconfigure.*;


import org.springframework.web.servlet.ModelAndView;

import com.wipro.asg.viewbean.ChangePasswordBean;

import com.wipro.asg.viewbean.LoginBean;
import com.wipro.asg.viewbean.MyCreditBean;
import com.wipro.asg.viewbean.MyDebitBean;
import com.wipro.asg.viewbean.PerformTransactionBean;
import com.wipro.asg.viewbean.RegistrationBean;

@RestController
@EnableAutoConfiguration

@RequestMapping("/OnlineBankingServices")
public class OnlineBankingController {

	public HashMap<Integer, RegistrationBean> mapRegUser = new HashMap<Integer, RegistrationBean>();
		public HashMap<Integer, PerformTransactionBean> map = new HashMap<Integer, PerformTransactionBean>();
	int amount=20000;
	int acct1 = 201900000;
	String user;
	
	MyDebitBean myDebitBean =new MyDebitBean();
	
	
	
	
	
	@RequestMapping(value = "performtransaction", method = RequestMethod.POST)
	public ModelAndView submitlogin(@ModelAttribute("loginBean") LoginBean loginBean) {
		String username = loginBean.getUserName();
		String password = loginBean.getPassword();
		
		
		if ((username.length()>0) && (password.isEmpty() )) {
			ModelAndView model1 = new ModelAndView("ForgotPasswordPage");
			String userName=loginBean.getUserName();
	Iterator<Map.Entry<Integer, RegistrationBean>> itr = mapRegUser.entrySet().iterator(); 
	        
	        while(itr.hasNext()) 
	        { 
	             Map.Entry<Integer, RegistrationBean> entry = itr.next(); 
	             if (userName.equals(entry.getValue().getUserName() )) {
	            	 model1.addObject("userName", userName);
	            	 model1.addObject("securityQuestion", entry.getValue().getSecurityQuestion());
	            	 
	            	 return model1;
	             }
	            	 
	             }
	        ModelAndView model2 = new ModelAndView("LoginPage");
	        model2.addObject("message", "User does not exist");
	        return model2;	
		}
		Iterator<Map.Entry<Integer, RegistrationBean>> itr = mapRegUser.entrySet().iterator(); 
        
        while(itr.hasNext()) 
        { 
             Map.Entry<Integer, RegistrationBean> entry = itr.next(); 
             String regUser = entry.getValue().getUserName();
             String regPass = entry.getValue().getPassword();
             String regConPass = entry.getValue().getConfirmPassword();
             
             if ((username.equals(regUser)) && (password.equals(regConPass))) {
     			
     			amount=entry.getValue().getAmount();
     			ModelAndView model1 = new ModelAndView("PerformTransactionPage");
     			model1.addObject("message", "Login Successful");
     			model1.addObject("amount", amount);
     			return model1;
     			
     		}  
       
		else if (!(username.matches("[a-zA-Z0-9]+"))) {
			ModelAndView model1 = new ModelAndView("LoginPage");
			model1.addObject("message", "User Name must be alphanumeric");
			return model1;
		} 
       }
			
			ModelAndView model1 = new ModelAndView("LoginPage");
			model1.addObject("message", "Invalid Input");
			return model1;
		
      }      
	

	@RequestMapping(value = "login", method = RequestMethod.POST)
	public ModelAndView register(@ModelAttribute("registrationBean") RegistrationBean registrationBean) {
		ModelAndView model1 = new ModelAndView("LoginPage");
		
		
		Random rand = new Random();
		int num = rand.nextInt(123457);
		
		mapRegUser.put(num, registrationBean);
		
		
		model1.addObject("message", "Registered Successfully");
		model1.addObject("mapRegUser",mapRegUser);
		return model1;
	}

	@RequestMapping(value = "cancel", method = RequestMethod.POST)
	public ModelAndView cancel(@ModelAttribute("registrationBean") RegistrationBean registrationBean) {
		ModelAndView model1 = new ModelAndView("LoginPage");
		return model1;
	}

	
	@RequestMapping(value = "submit", method = RequestMethod.POST)
	public ModelAndView submit(@ModelAttribute("changePasswordBean") ChangePasswordBean changePasswordBean) {
		ModelAndView model1 = new ModelAndView("ForgotPasswordPage");
		return model1;
	}

	@RequestMapping(value = "changepassword", method = RequestMethod.POST)
	public ModelAndView submitloginfor(@ModelAttribute("registrationBean") RegistrationBean registrationBean) {
		ModelAndView model1 = new ModelAndView("ForgotPasswordPage");
		
		String userName=registrationBean.getUserName();
		String answer=registrationBean.getAnswer();
		
		Iterator<Map.Entry<Integer, RegistrationBean>> itr = mapRegUser.entrySet().iterator();
				 
				  while(itr.hasNext()) { 
					  Map.Entry<Integer, RegistrationBean> entry = itr.next(); 
					  
					  if((answer.equals(entry.getValue().getAnswer())) && (userName.equals(entry.getValue().getUserName())) ) {
							ModelAndView model2 = new ModelAndView("ChangePasswordPage");
							user=userName;
					        return model2;		
						}
				 }
				 
				  model1.addObject("message", "Invalid Input");
				  model1.addObject("userName", userName);
				  model1.addObject("securityQuestion", registrationBean.getSecurityQuestion());
				  return model1;		
	}

	
	
	
	@RequestMapping(value = "login", method = RequestMethod.GET)
	public ModelAndView submitCancel() {
		ModelAndView model1 = new ModelAndView("LoginPage");
		return model1;
	}

	@RequestMapping(value = "changePassword", method = RequestMethod.POST)
	public ModelAndView submitChangePwd(@ModelAttribute("registrationBean") RegistrationBean registrationBean) {
		ModelAndView model1 = new ModelAndView("ChangePasswordPage");
		Iterator<Map.Entry<Integer, RegistrationBean>> itr = mapRegUser.entrySet().iterator();
		 
		  while(itr.hasNext()) { 
			  Map.Entry<Integer, RegistrationBean> entry = itr.next(); 
			  
			  if((registrationBean.getPassword().equals(registrationBean.getConfirmPassword())) && (user.equals(entry.getValue().getUserName())) ) {
					ModelAndView model2 = new ModelAndView("LoginPage");
					entry.getValue().setPassword(registrationBean.getPassword());
					entry.getValue().setConfirmPassword(registrationBean.getConfirmPassword());
					mapRegUser.replace(entry.getKey(), entry.getValue());
			        return model2;		
				}
		 }
		
		model1.addObject("message", "Invalid Input");
		return model1;
	}

	
	@RequestMapping(value = "mydebits", method = RequestMethod.GET)
	public ModelAndView myTransaction(
			@ModelAttribute("performTransactionBean") PerformTransactionBean performTransactionBean) {
		String name = performTransactionBean.getPayeeName(); 
		if (name!=null){
			Random rand = new Random(); 
			int transId = rand.nextInt(10000000);
		MyDebitBean myDebitBean = new MyDebitBean();
		myDebitBean.setToAccount(performTransactionBean.getPayeeAccountNumber());
		myDebitBean.setCheckbalance(performTransactionBean.getPbalance());
		myDebitBean.setAmount(performTransactionBean.getAmount());
		myDebitBean.setPayName(performTransactionBean.getPayeeName());
		if (amount < performTransactionBean.getAmount() ) {
			  ModelAndView model1 = new ModelAndView("PerformTransactionPage");
		      model1.addObject("message","Insufficient balance"); 
		      model1.addObject("amount", amount);
		      return model1;
		      }
		amount=balanceAmount(amount, performTransactionBean.getAmount());
		performTransactionBean.setPbalance(amount);
		map.put(transId, performTransactionBean);
		
		ModelAndView model1 = new ModelAndView("MyDebitsPage");
		model1.addObject("map", map);
		model1.addObject("amount", amount);
		return model1;
		}
		ModelAndView model1 = new ModelAndView("MyDebitsPage");
		model1.addObject("map", map);
		model1.addObject("amount", amount);
		return model1;
		
	}
	
	
	 @RequestMapping(value = "performtransaction", method = RequestMethod.GET)
	  public ModelAndView myPerformTransaction(
	  
	  @ModelAttribute("performTransactionBean") PerformTransactionBean
	  performTransactionBean) { ModelAndView model1 = new
	  ModelAndView("PerformTransactionPage"); model1.addObject("amount", amount);
	 return model1; }
	
	
	@RequestMapping(value = "btnCancel", method = RequestMethod.POST)
	public ModelAndView PerCancel(@ModelAttribute("performTransactionBean") PerformTransactionBean performTransactionBean) {	
		ModelAndView model1 = new ModelAndView("PerformTransactionPage");
		model1.addObject("amount", amount);
		return model1;
	}
	
	
	@RequestMapping(value = "registration", method = RequestMethod.POST)
	public ModelAndView myTransactions(@ModelAttribute("RegistrationBean") RegistrationBean registrationBean) {
		String acct = "ABC";
		Random rand = new Random();
		int num = rand.nextInt(123457);
		acct1 = acct1 + 1;
		String accNumber = acct + acct1;
				
		ModelAndView model1 = new ModelAndView("RegistrationPage");
		model1.addObject("accNumber",accNumber);
		return model1;
	}

	public int balanceAmount(int amount, int damount) {
		int balance = amount - damount;
		return balance;
	}

	public int pBalance(int pbalance, int amount) {
		int prbalance = pbalance - amount;
		
		return prbalance;
	}


	@RequestMapping(value = "mycredits", method = RequestMethod.GET)
	public ModelAndView myTransactions(@ModelAttribute("myCreditBean") MyCreditBean myCreditBean) {
		/* Random rand = new Random(); */
		ModelAndView model1 = new ModelAndView("MyCreditsPage");
		return model1;
	}
	
}
