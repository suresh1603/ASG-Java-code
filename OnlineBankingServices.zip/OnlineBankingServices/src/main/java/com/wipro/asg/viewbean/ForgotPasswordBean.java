package com.wipro.asg.viewbean;

public class ForgotPasswordBean {
	private String userName;
	private String securityQuestion;
	private String answer;

	public ForgotPasswordBean() {
		
	}
	
	public ForgotPasswordBean(String userName, String securityQuestion, String answer) {
		super();
		this.userName = userName;
		this.securityQuestion = securityQuestion;
		this.answer = answer;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getSecurityQuestion() {
		return securityQuestion;
	}

	public void setSecurityQuestion(String securityQuestion) {
		this.securityQuestion = securityQuestion;
	}

	public String getAnswer() {
		return answer;
	}

	public void setAnswer(String answer) {
		this.answer = answer;
	}

}
