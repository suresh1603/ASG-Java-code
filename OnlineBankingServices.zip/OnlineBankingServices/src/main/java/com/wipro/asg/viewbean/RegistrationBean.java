package com.wipro.asg.viewbean;



public class RegistrationBean {
	private String accountNumber;
	private String accountType;
	private String userName;
	private String password;
	private String confirmPassword;
	private String gender;
	private String email;
	private String address;
	private String securityQuestion;
	private String answer;
	private int amount;
	
	public RegistrationBean() {
		
	}
	
	public RegistrationBean(String accountNumber, String accountType, String userName, String password,
			String confirmPassword, String gender, String email, String address, String securityQuestion,String answer, int amount) {
		super();
		this.accountNumber = accountNumber;
		this.accountType = accountType;
		this.userName = userName;
		this.password = password;
		this.confirmPassword = confirmPassword;
		this.gender = gender;
		this.email = email;
		this.address = address;
		this.securityQuestion = securityQuestion;
		this.answer = answer;
		this.amount = amount;
	}
	public String getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getConfirmPassword() {
		return confirmPassword;
	}
	public void setConfirmPassword(String confirmPassword) {
		this.confirmPassword = confirmPassword;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getSecurityQuestion() {
		return securityQuestion;
	}
	public void setSecurityQuestion(String securityQuestion) {
		this.securityQuestion = securityQuestion;
	}
	public int getAmount() {
		return amount;
	}
	public void setAmount(int amount) {
		this.amount = amount;
	}

	public String getAnswer() {
		return answer;
	}

	public void setAnswer(String answer) {
		this.answer = answer;
	}

}
