 $(document).ready(function(){
function submitForm(){
	var payeeAccountNumber = $("#payeeAccountNumber").val(); 
	    
	var validator = $("#performForm").validate({
		
		rules:{
			payeeAccountNumber:{
				required:true,
			}
			
		},
		errorElement:"span",
		messages:{
			payeeAccountNumber:"Please select payeeAccountNumber"
			
		}
	});
	if(validator.form()){
		$('form#performForm').attr({
			action:'mydebits'
		});
		$('form#performForm').submit();
	} 
}
 });
