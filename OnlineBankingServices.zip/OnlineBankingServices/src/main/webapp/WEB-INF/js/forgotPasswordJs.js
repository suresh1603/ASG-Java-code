$(document).ready(function(){
function submitForm(){
	
	var answer = $("#answer").val(); 
	var validator = $("#forgotForm").validate({
		
		rules:{
			answer:{
				required:true,
				maxlength:30
			}
		},
		errorElement:"span",
		messages:{
			userName:"Please enter Answer"
			
		}
	});
	if(validator.form()){
		
		$('form#forgotForm').attr({
			action:'changepassword'
		});
		$('form#forgotForm').submit();
	} 
}
});