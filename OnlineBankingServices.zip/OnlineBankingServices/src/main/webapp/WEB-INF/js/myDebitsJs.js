 $(document).ready(function(){
function submitForm(){
	var accNum1 = $("#accNum1").val(); 
	  var payeeName1 = $("#payeeName1").val(); 
	  var amount1 = $("#amount1").val();  
	  var remarks1 = $("#remarks1").val();  
	var validator = $("#debitsForm").validate({
		
		rules:{
			accNum1:{
				required:true,
			},
			payeeName1:{
				required:true,
			},
			amount1:{
				required:true,
			},
			remarks1:{
				required:true,
			}
		},
		errorElement:"span",
		messages:{
			accNum1:"Please select Account number",
			payeeName1:"Please enter payeeName",
			amount1:" Please enter Amount ",
			remarks1:" Please enter remarks "
		}
	});
	if(validator.form()){
		$('form#debitsForm').attr({
			action:'mydebits'
		});
		$('form#debitsForm').submit();
	} 
}
 });
