 $(document).ready(function(){
function submitForm(){
	
	var userName = $("#userName").val(); 
	  var userPass = $("#password").val(); 
	  
	var validator = $("#loginForm").validate({
		
		rules:{
			userName:{
				required:true,
				minlength:6,
				maxlength:30
			},
			password:{
				required:true,
				minlength:6,
				maxlength:30
			}
		},
		errorElement:"span",
		messages:{
			userName:"Please enter UserName",
			password:"Please enter Password"
		}
	});
	if(validator.form()){
		
		$('form#loginForm').attr({
			action:'performtransaction'
		});
		$('form#loginForm').submit();
	} 
}
 });
