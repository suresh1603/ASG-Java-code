$(document).ready(function(){
function submitForm(){
	
	var answer = $("#password").val(); 
	var answer = $("#confirmPassword").val(); 
	var validator = $("#changeForm").validate({
		
		rules:{
			password:{
				required:true,
				maxlength:30
			},
			confirmPassword:{
				required:true,
				maxlength:30
			}
		},
		errorElement:"span",
		messages:{
			password:"Please enter password",
			confirmPassword:"Please enter confirmPassword"
		}
	});
	if(validator.form()){
	
		$('form#changeForm').attr({
			action:'changePassword'
		});
		$('form#changeForm').submit();
	} 
}
});