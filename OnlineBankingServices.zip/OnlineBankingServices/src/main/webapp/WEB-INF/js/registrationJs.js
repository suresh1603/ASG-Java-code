$(document).ready(function(){
function submitForm(){
	  
	  var password = $("#password").val(); 
	  var confirmPassword = $("#confirmPassword").val(); 
	  var email = $("#email").val(); 
	  var address = $("#address").val();
	  var answer = $("#answer").val(); 
	  var amount = $("#amount").val();
	  var validator = $("#registerForm").validate({
		
		rules:{
			
			password:{
				required:true,
				minlength:6,
				maxlength:30
			},
			confirmPassword:{
				required:true,
				minlength:6,
				maxlength:30
			},
			email: {
		        required: true,
		        email: true
		      },
		      address:{
				required:true,
				maxlength:30
			},
			answer:{
				required:true,
				maxlength:30
			},
			amount:{
				required:true,
				maxlength:5,
				minlength:1
			}
		},
		errorElement:"span",
		messages:{
			
			password: {
		        required: "Please provide a password",
		        minlength: "Your password must be at least 6 characters long"
		        	
		      },
		      confirmPassword: {
			        required: "Please provide a password",
			        minlength: "Your password must be at least 6 characters long"
			        	
			      },
			      address: {
				        required: "Please provide a password",
				        minlength: "Your address must be at least 30 characters long"
				        	
				      },
				      answer: {
					        required: "Please provide a password",
					        minlength: "Your answer must be at least 30 characters long"
					        	
					      },
					      amount: {
						        required: "Please provide a password",
						        minlength: "Your amount must be at least 1 number"
						        	
						      },
		      email: "Please enter a valid email address"
		    	  
		}
	});
	if(validator.form()){
		
		$('form#registerForm').attr({
			action:'login'
		});
		$('form#registerForm').submit();
	} 
}
});