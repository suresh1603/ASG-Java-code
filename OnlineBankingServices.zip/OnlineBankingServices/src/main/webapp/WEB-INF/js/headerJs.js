 $(document).ready(function(){
function submitForm(){
	  
	var validator = $("#headerForm").validate({
		
		rules:{
			amount:{
				required:true,
			}
		},
		errorElement:"span",
		messages:{
			
			
		}
	});
	if(validator.form()){
		$('form#headerForm').attr({
			action:'Header'
		});
		$('form#headerForm').submit();
	} 
}
 });
