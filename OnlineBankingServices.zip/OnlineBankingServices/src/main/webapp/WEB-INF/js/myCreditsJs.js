 $(document).ready(function(){
function submitForm(){
	var fromAcc1 = $("#fromAcc1").val(); 
	  var senderName1 = $("#senderName1").val(); 
	  var amt1 = $("#amt1").val();  
	  var remarks1 = $("#remarks1").val();  
	var validator = $("#creditsForm").validate({
		
		rules:{
			fromAcc1:{
				required:true,
			},
			senderName1:{
				required:true,
			},
			amt1:{
				required:true,
			},
			remarks1:{
				required:true,
			}
		},
		errorElement:"span",
		messages:{
			fromAcc1:"Please select Account number",
			senderName1:"Please enter SenderName",
			amt1:" Please enter Amount ",
			remarks1:" Please enter remarks "
		}
	});
	if(validator.form()){
		$('form#creditsForm').attr({
			action:'mycredits'
		});
		$('form#creditsForm').submit();
	} 
}
 });
